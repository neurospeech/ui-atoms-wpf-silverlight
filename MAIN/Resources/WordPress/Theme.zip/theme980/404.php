<?php get_header(); ?>
<?php get_sidebar(1); ?>

					<div class="title-page02">
						
						<h2>Error 404 - Not Found</h2>
						
					</div>
	


</div>


<?php get_footer(); ?>

