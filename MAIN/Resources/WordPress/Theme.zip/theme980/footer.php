			</div>
				
		</div></div>
		
		<div class="footer">
			<div class="width">
				
				<div class="indent">
					<?php bloginfo('name'); ?> is proudly powered by <a href="http://www.wordpress.org" target="_blank">WordPress</a><br />
					<a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a> and <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>
					<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
					<!--{%FOOTER_LINK} -->
				</div>
				
			</div>
		</div>
		
	</div>
	
	<?php wp_footer(); ?>
	
	<script type="text/javascript">Cufon.now();</script>
	
</body></html>